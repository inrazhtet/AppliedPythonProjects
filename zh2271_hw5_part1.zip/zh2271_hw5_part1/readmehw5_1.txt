percolation.py

Design & Implementation

make_sites(n,p)

This function is going to take in the dimensions of the matrix and the probability of open sites (1)
and generate a square matrix.
I use np.random.choice method I found under numpy documentation.
It allows me to set the range of values I want it to random generate, in this case [0,1],
the size of the output array, which is n * n and the probability of the random generating range
which is for [0,1]..
I can modify the shape later on using the built-in method of shape.
Then, I enforce the data type of each entry to be integers using sites.astype(int)

# -*- coding: utf-8 -*-
"""
Created on Sun Apr  3 15:44:24 2016

@author: zarnihtet
uni: zh2271
This file containes functions for generating percolation site, 
reading a site vacancy, write a site vacancy matrix to a file getting vertical
flows and checking for percolation

"""

import numpy as np

def read_grid(infile_name):
    """Create a site vacancy matrix from a text file.

    infile_name is the name (a string)  of the
    text file to be read. The method should return 
    the corresponding site vacancy matrix represented
    as a numpy array
    """
    #opening the file to get the dimensions from the header line
    file = open(infile_name,'r')
    dim = int(file.readline())
    file.close()    
    #using genfromtxt file to read in the matrix, it should return the matrix
    #but a catch is put in place, header line is skipped
    svmatrix = np.genfromtxt(infile_name, skip_header = 1)
    #making sure datatype is int
    svmatrix = svmatrix.astype(int, copy = False)
    #if the returned dimension is not as we want, we force it to change
    if (dim != svmatrix.shape[0]):
        svmatrix.shape(dim,dim)
    return svmatrix


def write_grid(outfile_name,sites):
    """Write a site vacancy matrix to a file.

    outfile_name is a string that is the name of the
    text file to write to. sites is a numpy array
    representing the site vacany matrix to write
    """
    
    #grabbing the dimension of matrix to write to the header of the output file
    head = sites.shape[0]
    #format is %d to output only in integers
    np.savetxt(outfile_name, sites,fmt = '%d', header = str(head), comments = '') 


def vertical_flow(sites):
    """Returns a matrix of vacant/full sites (1=full, 0=vacant)
    sites is a numpy array representing a site vacancy matrix. This 
    function should return the corresponding flow matrix generated 
    through vertical percolation
    """
    row = sites.shape[0]
    col = sites.shape[1]
    sites2 = np.copy(sites)   
    for row in range(0,row):
        for col in range(0,col):
            if (sites2[row][col] == 0):
                sites2[:,col] = 0
    return sites2
    
    
def percolates(flow_matrix):
    """ Returns a boolean if the flow_matrix exhibits percolation
    flow_matrix is a numpy array representing a flow matrix
    the input has to be matrix after vertical flow. 
    
    """
    row = flow_matrix.shape[0]
    sumlrow = np.sum(flow_matrix[row-1,:],dtype = np.int64)
    if (sumlrow >= 1):
        return True 
    else:
        return False


def make_sites(n,p):
    """Returns an nxn site vacancy matrix
    Generates a numpy array representing an nxn site vacancy 
    matrix with site vaccancy probability p
    """
    #converting strings into ints
    n = int(n)
    prob = float(p)
    #outputing a numpy array using random choice
    sites = np.random.choice([0,1], n * n, p =[1-prob,prob])
    sites = sites.astype(int, copy = False)
    sites.shape = (n,n)
    return sites
    

    
    
    
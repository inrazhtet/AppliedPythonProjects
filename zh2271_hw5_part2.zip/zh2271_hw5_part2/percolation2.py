# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 10:07:41 2016

@author: Zarni Htet
uni: zh2271
description: This module contains functions to generate random sites for 
percolation, read them into file, write them into file, check for percolation,
a recursive function using depth-first seach, a function that returns directed
flow using the recursive helper function, a graph that traces the water flow
down the matrix and a probability plot graph of the vacancy probability vs
probability obtained from trials.
"""
import numpy as np
import matplotlib.pyplot as plt


def read_grid(infile_name):
    """Create a site vacancy matrix from a text file.

    infile_name is the name (a string)  of the
    text file to be read. The method should return 
    the corresponding site vacancy matrix represented
    as a numpy array
    """
    #opening the file to get the dimensions from the header line
    file = open(infile_name,'r')
    dim = int(file.readline())
    file.close()    
    
    #using genfromtxt file to read in the matrix, it should return the matrix
    #but a catch is put in place, header line is skipped
    svmatrix = np.genfromtxt(infile_name, skip_header = 1)
    
    #making sure datatype is int
    svmatrix = svmatrix.astype(int, copy = False)
    
    #if the returned dimension is not as we want, we force it to change
    if (dim != svmatrix.shape[0]):
        svmatrix.shape(dim,dim)
    return svmatrix


def write_grid(outfile_name,sites):
    """Write a site vacancy matrix to a file.

    outfile_name is a string that is the name of the
    text file to write to. sites is a numpy array
    representing the site vacany matrix to write
    """
    
    #grabbing the dimension of matrix to write to the header of the output file
    head = sites.shape[0]
    
    #format is %d to output only in integers
    np.savetxt(outfile_name, sites,fmt = '%d', header = str(head), comments = '') 


#Question: Serena: is this vertical flow correct?
def vertical_flow(sites):
    """Returns a matrix of vacant/full sites (1=full, 0=vacant)
    sites is a numpy array representing a site vacancy matrix. This 
    function should return the corresponding flow matrix generated 
    through vertical percolation
    """
    
    rows = sites.shape[0]
    col = sites.shape[1]
    sites2 = np.copy(sites)
    
    #the vertical flow would be from sites of that row and downwards.
    #fixed in the final version
    for row in range(0,rows):
        for col in range(0,col):
            if (sites2[row][col] == 0):
                sites2[row:,col] = 0
                
    return sites2
    
    
def percolates(flow_matrix):
    """ Returns a boolean if the flow_matrix exhibits percolation
    flow_matrix is a numpy array representing a flow matrix
    the input has to be matrix after vertical flow. 
    
    """
    row = flow_matrix.shape[0]
    sumlrow = np.sum(flow_matrix[row-1,:],dtype = np.int64)
    if (sumlrow >= 1):
        return True 
    else:
        return False


def make_sites(n,p):
    """Returns an nxn site vacancy matrix
    Generates a numpy array representing an nxn site vacancy 
    matrix with site vaccancy probability p
    """
    #converting strings into ints
    n = int(n)
    prob = float(p)
    
    #outputing a numpy array using random choice
    sites = np.random.choice([0,1], n * n, p =[1-prob,prob])
    sites = sites.astype(int, copy = False)
    sites.shape = (n,n)
    return sites
   
   
def directed_flow(sites):
    """Returns a matrix of vacant/full sites (1=full, 0=vacant)
    sites is a numpy array representing a site vacancy matrix. This     
    function should return the corresponding flow matrix generated     
    through directed percolation"""
    
    row_size = sites.shape[0]
    col_size = sites.shape[1]
    if (row_size != col_size):
        print("There is something wrong with your input matrix!")
    full = make_sites(row_size, 0)
    i = 0
    for j in range(0, col_size):
        flow_from(sites,full,i,j)
    return full
    
    
def flow_from(sites, full, i,j):
    """Adjusts the full array for flow from a single site
    This method does not return anything. 
    It changes the array full     Notice it is not side effect free"""
    
    row_limit = sites.shape[0]
    col_limit = sites.shape[1]
    
    #making sure we are not out of bounds in the rows
    if (i >= 0 and i <= row_limit -1):
        #making sure we are not out of bounds in the columns
        if (j >= 0 and j <= col_limit -1 ):
            #making sure they are not blocked
            if (sites[i][j] != 0):
                #making sure they are not filled already
                if (full[i][j] != 1):
                    full[i][j] = 1
                    flow_from(sites,full,i, j-1)
                    flow_from(sites,full,i,j+1)
                    flow_from(sites,full, i+1, j)
            

def show_perc(sites):
      """Displays a matrix using three colors for vacant, blocked, full         
      Used to visualize undirected flow on the matrix sites     """
      
      full = directed_flow(sites)
      chart = full + sites

      plt.matshow(chart)
      plt.show()
      
    
def make_plot(n, trials):
    """generates and displays a graph of percolation p vs vanacy p
        estimates percolation probability on an nxn grid for directed percolation
        by running a Monte Carlo simulation using the variable trials number
        of trials for each point"""
    
    #getting the evenly spaced probabilities segments for the tail, mid and 
    #head part. tail and head are spaced at lesser # of segments because their
    #probabilities are more or less going to be zero. The middle part has been
    #segmented further to smoothen a more rugged curve base on trial and error
    
    tail = np.linspace(0,0.29,4)
    mid  = np.linspace(0.30,0.77,47)
    head = np.linspace(0.78,1, 4)
    
    x = np.concatenate((tail,mid,head))
    y = []
    
    for i in x:          
        count = 0
        success = 0
        while (count < trials):  
            m = make_sites(n,i)
            d = directed_flow(m)
            if (percolates(d) == True):
                success +=1
            count +=1
        y.append(float(success/trials))
    
    #setting the title, xlables, ylables of the graph
    plt.title('Percoation Prob vs Site Vacancy Prob')
    plt.xlabel('Site Vacancy Prob')
    plt.ylabel('Percolation Prob')
    plt.plot(x,y)
    plt.show()

        
    
    

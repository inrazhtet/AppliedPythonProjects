name: Zarni Htet
uni: zh2771
------------------------------------------------------------
percolation.py

Design & Implementation

make_sites(n,p)

This function is going to take in the dimensions of the matrix and the probability of open sites (1)
and generate a square matrix.
I use np.random.choice method I found under numpy documentation.
It allows me to set the range of values I want it to randomly generate, in this case [0,1],
the size of the output array, which is n * n and the probability of the random generating range
which is for [0,1]..
I can modify the shape later on using the built-in method of shape.
Then, I enforce the data type of each entry to be integers using sites.astype(int, copy = False) 
to make sure the type is enforced and we are not wasting array space.

write_grid(outfile_name, sites)

This function is fairly straightforward.
I googled for a writetxt numpy function and found np.savetxt
which does most of what I want except for header. I have to grab the shape of the header
from the input and put it as a header on readtxt while making sure that there is nothing 
in front it setting the comments parameter as ''.

read_grid(infile_name)

This function is a little more complicated.
I googled and found through the numpy documentation, several readtext functions.
I chose np.genfromtxt because it appears to be more robust than .loadtxt in being able to handle
missing values. It also returns the nparray2D or our matrix in form.
I adjusted for the type using as.type(int, copy = False) as above. Although np.genfromtxt returns the
matrix in its matrix form, to make sure that I am in the proper dimensions, I have read in the header
and I am reinforcing it, in case, the dimension is not what I want.

vertical_flow(sites)

The concept of Vertical flow is that when we find a blocked site (0), everything that is under it will also
be blocked. If it's an open site, we leave as it is. Therefore, I have a n x n matrix
where I am only checking for cases when the site is blocked and subsequently, changing everything in that matrix 
column below that row to be zero. I have to loop through every single row because we can find some blocked sites in the lower rows
while all the upper rows can be opened.

percolates(flow_matrix)

The percolates function is checking if the medium percolates or not.
In theory, if the last row has at least one value of 1, then, we can be certain that it has percolated.
Therefore, the way I have checked is summing up the last row to see if it's greater equal to 1.
I return true. Otherwise, I return false.
The functions used are not anything fancy. I just had to google how to sum numpy array and grab the last row
in the matrix.


directed_flow(sites)

This function uses the recursive flow_from function belows to
apply depth-first search to the matrix medium. The only trick is to iterate through the first row of the for loop and make repetitive recursive calls.

flow_from(sites, full, i, j)

The flow_from recursive function is a little tricky. I based this one off professor Canon's lecture notes.
For a directed flow matrix, we are only considering the case where we check for path left, right and below.
Before that in order to apply recursion, we have
a) check whether our site is out of bounds in row 
b) is it out of bounds in column?
c) is it blocked in sites?
d) is it already filled?
if all conditions are checked, we then proceed to
i) fill it
b) then, recurse through right, left and down until the base conditions are met. As such if we recurse through from the top row of the matrix, we have searched for all possible routes after exploring the depth of each site on the top row.

show_perc(sites)

this function takes in the site matrix and get the flow matrix.
It superimposes, both matrix to get the case where we have a water flow that is the 2 values, where the water is partially blocked 1 values and where the water is totally blocked 0 values.

After many many trials, I have found that the best segments as below:
    tail = np.linspace(0,0.29,4)
    mid  = np.linspace(0.30,0.77,47)
    head = np.linspace(0.78,1, 4)
It is segmented that way from observations on 5,000 trials
to prevent sharp turns as well as jagged line.
More segments are in the middle part as they are more volatile compared to the tail and head where a success or a failure is more assured.


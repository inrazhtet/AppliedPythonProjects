# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 10:04:50 2016

@author: zarnihtet
"""

#*******************************************************
#hw5b module
#Assignment 5 Part 2
#ENGI E1006
#*******************************************************


import percolation2 as perc

def main():
    a=perc.make_sites(30,0.8)
    perc.write_grid('sites.txt',a)
    b=perc.read_grid('sites.txt')
    c=perc.directed_flow(b)
    if perc.percolates(c):
        print('percolates')
    else:
        print('does not percolate')

    
    #visualize flow
    perc.show_perc(b)

    #generate percolation probability graph
    perc.make_plot(10,5000)
    


main()

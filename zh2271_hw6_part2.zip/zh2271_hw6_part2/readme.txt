HW6Part2:
Author: Zarni Htet
UNI: zh2271
=======================
Compared to the first problem, this is much easier. I made three major changes which is modifying the NNClassifier, including two new helpers
to handle the new parameters.

How to run my program:

My test and main function is very thin. All you have to do is generate data and call datarun(withgenerateddata) and then, call resultout(outputfrombefore, "typeofdata") to get the optimal k-value and accuracy results.

Or  run my main file.

----------
def readfile(infilename)

I simply used genfromtxt like last time with the only difference being the delimiter and forcing everything to string

The other part is deleting the extra column of ids and a for loop to go and dummy the Ms and Bs. I couldn't find a built-in function to handle the dummies.

--------
def synthetic(sample_size)

I use the multivariate_normal whic is pretty forward. The little added on is, I can vary the length of the sample sizes for each.

Then, I use np.insert function to include in the 0 position of each row (each row being a numpy array), the label values 0 and 1.

I concatenate both data sets afterwards.

--------
def KNNclassifier(training,test)

I first make sure that everything is a float by using the niftty as.type with copy = false.

Then, the main function is cdist. It returns a matrix of the difference between test row and each of the training row. It's important the first matrix in cdist is test because we want to run it across all the training data sets of it. Each row of the return matrix will contain the difference with that row of the test and each of the training set.

I use argsort which returns the matrix (array of array) containing all the indexes from min and max from the training set.

Therefore, through a for loop, I have to use the first column of the return matrix of argsort to correspondingly put in the labels drawn from the training set of the corresponding training set.
-
The slight modification for the KNN classifier is that I have to add in a chunk of code that takes in the first k columns/items of each row of the index and correspondingly interfacing with the training data set's label column.
The mode was pretty straightforward with needing to catch for non-split cases.

--------------
def n_validator(data p, classifier, *args)

We first make sure that the partition is an int.
We shuffle the data and then, we have to use array_split
to make sure that the arrays are split in the most reasonable manner.

Another bump is how to take care of the training data when we take each component of the split.
I use a for loop to check if the test index being used, I do not use it for training. I use extend so that I would be putting in list of arrays which I can then easily switch it to numpy array (or matrix)

Then, the only thing left is running through the labels from the classifier function and comparing it that particular test in that particular data split.

It's important the score is outside of the for loop since we are accounting for everything and dividing it by the total size
--
Nothing much changes here since args is already part of the argument.
--------------
def datarun(data):

This is the function that takes in distance list and account for the odd ks up to 15 and put it into the validator function which in turns calls
the classifier.
All the accuracy results are returned as a numpy array
---------------
def resultout(results, *args):

This function is to handle for finding optimal k-values and account for the type of data I am inputting (*args is a string argument of data type) that distinguishes in our print statements.
Finding the optimal result is easy. We sort the index of the accuracy array to distinguish which distance function has been used.
Then, we use simple mathematical relations between the index of the accuracy array and actual k value to figure out the k and we also call the accuracy value
straight using the index of the array.


to put.




# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 16:48:16 2016
@author: zarnihtet, 
@uni:zh2271,
@description: This main function imports the nn module and read data from 
real data, generate synthetic data with varying sample size and then, run
through the validator to print out the accuracy rate
"""

import knn as nn
import numpy as np


def main():
    
    """
    This function uses multipler helper functions to 
    read in the data, generates synthetic data, runs KNNclassifier
    across multiple k and distance functions and outputs the optimal results
    across two different types of data set.
    """
    #Synthetic data results
    syntheticdata = nn.synthetic(300)
    rsynthetic = nn.datarun(syntheticdata)
    nn.resultout(rsynthetic,"synthetic data")
    
    #Real data results
    realdata = nn.readfile('wdbc.data.txt')
    rreal = nn.datarun(realdata)
    nn.resultout(rreal, "real data")

main()
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 16:20:22 2016
@author: zarnihtet
uni: zh2271
description: This module contains functions that read the Breast Cancer File,
generate synthetic data, outline the knn classifier which calculates the distance 
between the k row from testing and the rest of the training data set, the type
of distance the and a Validator which takes in data(splitting is done in this
function),the number of splits you want to do, type of classifier and rest 
of arguments.

"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
from scipy.spatial.distance import euclidean
import statistics
import random


def readfile (infile_name):
    """
    This function reads in the wdbc data and it cleans it by removing the id and
    categorize M and B into 0s and 1s
    """
    #read from data file with the comma as the split. It will import a smiliar
    #matrix type data
    info = np.genfromtxt(infile_name, dtype = str, delimiter = ",", skip_header = 0)
    
    #We delete the first column of that info data file
    info2 = np.delete(info, 0, 1)
    count = 0
    
    #Go through the data set and assign M and B respectively
    for i in range(0, len(info2)):
        if (info2[i][0] == "M"):
            count +=1
            info2[i][0] = 1
        elif(info2[i][0] == "B"):
            count +=1
            info2[i][0] = 0
    #print(count)    
    return info2
    
    
def synthetic(sample_size) :
    """
    This function generates the synthetic data of multivariate normal 
    distribution with variable sample size
    """
    
    #make sure the size of the sample is and int
    size = int(sample_size)
    
    #generating multivariate normal with mean and covariates
    set1 = np.random.multivariate_normal([2.5,3.5],[[1,1],[1,4.5]],size)
    set2 = np.random.multivariate_normal([0.5,1],[[2,0],[0,1]],size)
    
    #insert the 0s and 1s for the data set
    set1 = np.insert(set1,0,0,axis = 1)
    set2 = np.insert(set2,0,1,axis = 1)
    
    #concatenate the two sets of the data
    set3 = np.concatenate((set1,set2), axis = 0)
    
    return set3

def KNNclassifier(training, test, k,d,*args):
    """
    This function takes in training and testing data and it predicts the labels
    of the testing data by calculating the euclidean or manhattan or minkowski 
    distance between each row
    of the data set and the training set and finding the minimum row by 
    sorting the index of the cdist return matrix and interfacing it with the 
    main matrix
    """
    
    #change data from string type to float    
    training = training.astype(float, copy = False)
    #print(training)
    test = test.astype(float, copy = False)
    
    #Figure out the length of the training data for the for loop below to find
    #miniumum
    indexes = np.size(test,0)
    
    #Create an empty numpy array to add in the labels
    labels = np.empty([indexes,1], dtype = float)
    
    #This calculates the euclidean distance between the test row and the trai
    #ing data row and provides by a mxn matrix
    dist = cdist(test,training[:,1:],d, *args)
    #print(dist)
    
    #We sort the cdist return of each row to get a return matrix array where
    #the first column has all the minimum index of each test row's
    #We can then refer to the training data set to grab the appropriate labels
    index = np.argsort(dist)
    #print(index)
    for i in range(0, len(index)):
        
        #We get the first k index of each row of the Index array
        #interface it with training label column and then, find the mode
        #try, except is to handle a random case
        
        try:        
            multi_index = training[index[i][0:k],0]
            mode_index  = statistics.mode(multi_index)
            labels[i] = mode_index
        
        except statistics.StatisticsError:
            labels[i]= random.randint(0,1)        
        
    return labels


def n_validator(data, p, classifier, *args):
    """
    This function takes in the data set, the number of data partition we want,
    the type of classifier and other possible arguments. It returns the 
    accuracy score of the NN and if we have additional arguments, it would work
    for K-Nearest Neighbors
    """  
    
    #making sure the partiion is an int
    p = int(p)
    
    #we shuffle the data
    np.random.shuffle(data)
    
    #we split the data using array_split. It's meant to take care even uneven
    #arrays
    splitdata = np.array_split(data,p)
    
    #this is be the base for the accuracy score
    size = len(data)    
    
    #this is the score
    score = 0
    for i in range(0,p):
        
        testing = splitdata[i]
        
        #To save the training data
        training = []
        lensplit = len(splitdata)
        
        #Training data being put into a python list of list
        for j in range(0,lensplit):
            #Adding the non-test included to training data
            if (j!=i):
                training.extend(splitdata[j])
        finaltraining = np.asarray(training)
        #input to the classifier training and testing where in classifier
        #we aldy handle how training data would be, #args is to account for
        #k, d and other parameters
        
        labels = classifier(finaltraining,testing[:,1:],*args)
        #print("Break")
        
        #Looping through to check if training label and actual label are the same.
        #And keeping track of score
        for i in range(0,len(labels)):
            if (int(labels[i]) == int(testing[i][0])):
                #print(score)
                score = score + 1
    #print("Final Score")    
    #print (float(score/size))
    return float(score/size)
    
    
def datarun(data):
    """
    This function calculates the accuracy across all types of distance and k
    functions and return a numpy array containing all the accuracies
    """
    
    #types of distances
    distance = ['euclidean','cityblock','minkowski']
    
    #numpy array and its size to hold accuracy values
    size = len(distance) * len([i for i in range(1,16,2)])
    accuracy = np.empty([size,1],dtype = np.float64)
    
    count = 0
    
    #minkowski has an additional parameter to account for
    for d in distance:
        for k in range (1,16,2):
            if d == "minkowski":
                accuracy[count] = n_validator(data,5,KNNclassifier,k,d,3)
            else:
                accuracy[count] = n_validator(data,5,KNNclassifier,k,d)
            count = count + 1    
    return accuracy

def resultout(results, *args):
    """    
    This function is to handle the issue of finding the optimal k value,
    accuracy results and distinguish between different input data types
    """
    
    #checking which type of data I put it in
    if args:
        datatype = str(args[0])
    
    #Getting the index from the accuracy array to distinguish which
    #distance function it belongs to
    
    optimalvalue = np.argmax(results)
    if optimalvalue <= 7: 
        print("The accuracy of the " + datatype + "  is: ")
        print(float(results[optimalvalue]))
        print("The distance function used is Euclidean and the K-Value is ") 
        print(optimalvalue * 2 + 1)
    elif (optimalvalue >7 and optimalvalue <=15):
        print("The accuracy of the " + datatype + "  is: ")
        print(float(results[optimalvalue]))
        print("The distance function used is Manhattan and the k-value is ")
        print((optimalvalue-8) * 2 + 1)
    elif (optimalvalue >15 and optimalvalue <=23):
        print("The accuracy of the " + datatype + "  is: ")
        print(float(results[optimalvalue]))
        print("The distance function used is Minkowski and the k-value is ")
        print((optimalvalue-16) * 2 + 1)
    
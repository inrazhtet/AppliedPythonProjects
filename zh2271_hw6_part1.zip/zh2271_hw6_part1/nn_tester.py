# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 16:48:16 2016
@author: zarnihtet, 
@uni:zh2271,
@description: This main function imports the nn module and read data from 
real data, generate synthetic data with varying sample size and then, run
through the validator to print out the accuracy rate
"""
import nn as nn

def main():
    
    """
    This function reads in the data, generates synthetic data, runs out NN
    classifier and print out the accuracy rate
    """
    
    realdata = nn.readfile('wdbc.data.txt')
    syntheticdata = nn.synthetic(300)
    
    realdataaccuracy = nn.n_validator(realdata,5,nn.NNclassifier)
    syndataaccuracy = nn.n_validator(syntheticdata,5,nn.NNclassifier)
    
    print("The accuracy of the real data is: {0:.3f} ".format(realdataaccuracy))
    print("The accuracy of the synthetic data is: {0:.3f} ".format(syndataaccuracy))
main()